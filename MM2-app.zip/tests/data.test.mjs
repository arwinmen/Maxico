import test from "node:test";
import assert from "node:assert/strict";
import { exercises, routines } from "../data.js";

test("todas las rutinas apuntan a ejercicios existentes", () => {
  for (const routine of routines) {
    assert.ok(routine.exerciseIds.length >= 4);
    for (const id of routine.exerciseIds) assert.ok(exercises[id], `${routine.id} referencia ${id}`);
  }
});

test("cada ejercicio tiene instrucciones suficientes", () => {
  for (const [id, exercise] of Object.entries(exercises)) {
    assert.ok(exercise.name && exercise.muscle && exercise.dose, id);
    assert.ok(exercise.cues.length >= 3, id);
  }
});
